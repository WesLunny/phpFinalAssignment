<?php
/******************************************************************************

Final Project Php Westley Lundberg

This program allows for the user to play 5 card poker against the dealer

*******************************************************************************/

$pot=0;

$bank = (int)readline("Enter the amount of Chips you have to bet with: "); 
$bet = 0;
$folded = false;
$checked = false;
$playerHand =[];
$dealerHand =[];

$deck = [];

function createDeck(&$deck){
    $suits = ['Hearts', 'Spades', 'Clubs', 'Diamonds'];
    $values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
    foreach ($suits as $suit) {
        foreach ($values as $value) {
            $deck[] = ['suit' => $suit, 'value' => $value];
        }
    }
}

function dealCards(&$deck,&$hand){
    for ($i = 0; $i < 5; $i++) {
        $hand[$i] = array_pop($deck); // Draw a card from the top of the deck
    }
}//end of dealCards


function playersTurn(&$folded,&$checked){
    while(true){
        $playerAction = readline(" Would You Like To (B)et, (C)heck or (F)old: ");
        $playerAction = strtoupper($playerAction);
        
        if($playerAction == 'B'){
            echo "You are betting.\n";
            break;
        }
        else if ($playerAction == 'C') {
            echo "You check.\n";
            $checked = true;
            break;
        }
        else if($playerAction == 'F'){
            $folded = true;
            break;
        }
        else{
            echo "Must Enter (B)et (C)heck or (F)old.\n";
        }
    }
}


function hasFlush($hand) {
    $suits = array_column($hand, 'suit');
    $unique_suits = array_unique($suits);
    return count($unique_suits) == 1;
}

// Function to check if a hand is a straight
function isStraight($hand) {
    $values = array_column($hand, 'value');
    sort($values);
    $prev_value = null;
    foreach ($values as $value) {
        if ($prev_value !== null && $value != $prev_value + 1) {
            return false;
        }
        $prev_value = $value;
    }
    return true;
}

// Function to check if a hand has a pair
function hasPair($hand) {
    $values = array_column($hand, 'value');
    $value_counts = array_count_values($values);
    return in_array(2, $value_counts);
}

// Function to check if a hand has three of a kind
function hasThreeOfAKind($hand) {
    $values = array_column($hand, 'value');
    $value_counts = array_count_values($values);
    return in_array(3, $value_counts);
}

function hasFourOfAKind($hand){
    $values = array_column($hand, 'value');
    $value_counts = array_count_values($values);
    return in_array(4, $value_counts);
}

// Function to check if a hand has a full house
function hasFullHouse($hand) {
    $values = array_column($hand, 'value');
    $value_counts = array_count_values($values);
    return in_array(2, $value_counts) && in_array(3, $value_counts);
}


// Function to determine the poker hand ranking
function determineHandRanking($hand) {
    if (hasFlush($hand) && isStraight($hand)) {
        return "Straight Flush";
    } elseif (hasFullHouse($hand)) {
        return "Full House";
    } elseif (hasFlush($hand)) {
        return "Flush";
    } elseif (isStraight($hand)) {
        return "Straight";
    } elseif (hasThreeOfAKind($hand)) {
        return "Three of a Kind";
    } elseif (hasPair($hand)) {
        return "Pair";
    } else {
        return "High Card";
    }
}

function determineHandStrength(&$hand){
    if (hasFlush($hand) && isStraight($hand)) {
        return 7;
    } elseif (hasFullHouse($hand)) {
        return 6;
    } elseif (hasFlush($hand)) {
        return 5;
    } elseif (isStraight($hand)) {
        return 4;
    } elseif (hasThreeOfAKind($hand)) {
        return 3;
    } elseif (hasPair($hand)) {
        return 2;
    } else {
        return 1;
    }
}

function playAgain(){
    while(true){
    $playAgain = readline("\n Would You Like To Play Again? (y or n):" );
    $playAgain = strtolower($playAgain);
        
    if($playAgain === 'n'){
        return false;
        break;
    }
    elseif($playAgain === 'y'){
        return true;
        break;
        
    }
    else{
        echo "Enter y or n";
    }
    }
    
}

while(true){//game loop
    //ante
    echo "Pay The Ante\n";
    $bank -= 20;
    $pot += 20;
    echo "Bank: $bank \n";
    echo "Pot: $pot \n";
    
    //shuffle and deal
    createDeck($deck);
    shuffle($deck);
    dealCards($deck,$playerHand);
    dealCards($deck,$dealerHand);
    //print_r($deck);
    //Bet
    echo "Your Hand: \n";
    print_r($playerHand);
    echo "You have a ".determineHandRanking($playerHand);
    playersTurn($folded,$checked);
    
    if($folded ==false && $checked == false){
        while (true) {
            echo "Bank: $bank \n";
            $bet = (int)readline('Place Your Bets: ');
            if ($bet > $bank) {
                echo "You Cannot Afford That Bet.\n";
            } 
            elseif ($bet <= 0) {
                echo "Invalid bet amount. Please enter a positive number.\n";
            }
            elseif($bet < 20){
                echo "Bet must be more than Ante (20).\n";
            }
            else {
                $bank -= $bet;
                $pot += $bet;
                echo "Bank: $bank\n";
            //echo $bet;
                break; // Exit the bet input loop if the bet is valid
            }
        }
    }
    //showdown
    if($folded == false){
        if(determineHandStrength($playerHand) > determineHandStrength($dealerHand)){
            echo"You Won!, pot added to Bank.\n";
            echo "The dealer had a ".determineHandRanking($dealerHand);
            $bank += $pot;
            $pot = 0;
            echo"\n$bank";
        }
        elseif(determineHandStrength($playerHand) == determineHandStrength($dealerHand)){
            echo "You split the pot.\n";
            echo "The dealer had a ".determineHandRanking($dealerHand);
            $pot = $pot / 2;
            $bank +=$pot;
            $pot =0;
            echo "\n $bank";
        }
        else{
            echo "The dealer won.\n";
            echo "The dealer had a ".determineHandRanking($dealerHand);
            $pot =0;
            echo "\n$bank";
        }
    }
    //play again
    if (!playAgain()) {
        break;
    } 
}
